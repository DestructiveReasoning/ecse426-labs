var searchData=
[
  ['get_5fdisplay_5fleds',['get_display_leds',['../voltmeter_8c.html#abf9f113fd0f70a6bc4bbe026d0ec54d2',1,'voltmeter.c']]]
];
