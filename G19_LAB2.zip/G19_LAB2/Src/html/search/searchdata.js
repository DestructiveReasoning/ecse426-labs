var indexSectionsWithContent =
{
  0: "_acdefghmprsv",
  1: "msv",
  2: "_adefghmps",
  3: "acdhrs",
  4: "as",
  5: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros",
  5: "Modules"
};

