var searchData=
[
  ['display_5fnum',['display_num',['../main_8c.html#aec6b12e3817e2475ae3dc769cf27b1ca',1,'main.c']]]
];
